# Security Policy

If you have found any issue regarding security, please send an email [marco.sottana@gmail.com](mailto:marco.sottana@gmail.com) instead of using the issue tracker and we will quickly work on it.
