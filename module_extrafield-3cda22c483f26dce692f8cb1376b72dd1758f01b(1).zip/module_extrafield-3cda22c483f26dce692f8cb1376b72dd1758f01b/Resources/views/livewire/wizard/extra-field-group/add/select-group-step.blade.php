<x-layout.wizard :steps="$steps">
    <x-input.group type="select" name="group_id" :options="$groups" class="mb-5" />
</x-layout.wizard>
