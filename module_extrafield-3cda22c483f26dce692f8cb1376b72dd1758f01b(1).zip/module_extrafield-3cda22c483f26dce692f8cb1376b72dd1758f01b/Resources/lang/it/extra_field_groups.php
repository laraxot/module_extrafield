<?php

declare(strict_types=1);

return [
    'tab' => [
        'edit' => 'Modifica',
        'create' => 'Aggiungi',
        'index' => 'Lista',
    ],
];
