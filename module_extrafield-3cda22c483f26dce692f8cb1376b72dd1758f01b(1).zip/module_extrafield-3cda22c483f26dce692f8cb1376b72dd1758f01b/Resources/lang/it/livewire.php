<?php

declare(strict_types=1);

return [
    'modal' => [
        'extra-field-group' => [
            'add' => 'Aggiungi Campo',
        ],
    ],
];
