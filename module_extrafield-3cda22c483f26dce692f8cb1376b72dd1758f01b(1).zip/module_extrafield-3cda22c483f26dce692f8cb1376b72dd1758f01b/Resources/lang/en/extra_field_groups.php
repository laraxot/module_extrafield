<?php

declare(strict_types=1);

return [
    'tab' => [
        'edit' => 'Edit',
        'create' => 'Add',
        'index' => 'List',
    ],
];
